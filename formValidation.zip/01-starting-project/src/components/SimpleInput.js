import React from 'react'
import { useState } from 'react';

const SimpleInput = (props) => {
  const [userName, setUserName] = useState('')
  const [nameValid, setNameValid] = useState(false)
  const [touched, setTouched] = useState(false)

  const [password1, setPassword1] = useState('')
  const [password2, setPassword2] = useState('')
  const [ptouched, setPtouched] = useState(false)
  const [pValid, setPvalid] = useState(false)

  const [finalValid, setFinalValid] = useState(false)

  const password1Handler = (event) => {
    setPassword1(event.target.value)
  }

  const password2Handler = (event) => {
    setPassword2(event.target.value)
    if (password1.trim() === password2.trim()) {
      setPvalid(true)
    }

  }

  const nameHandler = (event) => {
    setUserName(event.target.value)
    if (event.target.value.trim() !== '') {
      setNameValid(true)

    }
  }
  const nameBlur = () => {
    if (userName.trim() === '') {
      setNameValid(false)
      setTouched(true)
    }
  }
  const passBlur = (event) => {
    if (password1.trim() !== event.target.value.trim()) {
      setPtouched(true)
      setPvalid(false)

    }
  }
  const submitHandler = (event) => {
    event.preventDefault()
    if (userName.trim() === '') {
      setNameValid(false)
      setTouched(true)
    }
    setFinalValid(true)
    setUserName('')
    setPassword1('')
    setPassword2('')
  }



  return (
    <form>

      <div className='form-control'>
        <label htmlFor='name'>UserName</label>
        <input
          value={userName}
          onBlur={nameBlur}
          onChange={nameHandler} type='text' id='name' />
      </div>
      {!nameValid && touched && <p className='error-text'>Username cannot be empty</p>}


      <div className='form-control'>
        <label htmlFor='name'>Password</label>
        <input
          value={password1}
          onBlur={passBlur}
          onChange={password1Handler} type='password' id='name' />
      </div>

      <div className='form-control'>
        <label htmlFor='name'>Confirm Password</label>
        <input
          value={password2}
          onBlur={passBlur}
          onChange={password2Handler} type='password' id='name' />

        {ptouched && !pValid && <p className='error-text'>password does'nt match</p>}
      </div>

      <div className="form-actions">
        <button onClick={submitHandler}>Submit</button>
      </div>
    </form>
  );
};

export default SimpleInput;
